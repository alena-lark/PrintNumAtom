'''
Printing number of atoms in molecule
'''
import numpy as np

def printnum():
    
    a = np.array([1, 2, 3])

    return print("inisial step", a)
    