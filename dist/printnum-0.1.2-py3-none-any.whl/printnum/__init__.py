# import a function
# if file-name, then not recognize
import PrintNumAtom
