'''
Printing number of atoms in molecule
'''
import numpy as np

def __init__():
    
    a = np.array([1, 2, 3])
    print("inisial step", a)
    
    return 1
    