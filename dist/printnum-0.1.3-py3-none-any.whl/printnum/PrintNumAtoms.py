'''
Printing number of atoms in molecule
'''
import numpy as np

def PrintNumAtoms(num):
    a = np.array([1, 2, 3, num])
    return a
    